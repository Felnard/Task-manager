<?php

	//Mga data para makaconnect, pwede magiba per user
	define('ROOT_URL', '');
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', 'dendi1234');
	define('DB_NAME', 'info');
	